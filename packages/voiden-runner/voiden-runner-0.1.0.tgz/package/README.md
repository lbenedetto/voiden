# @voiden/runner

Headless CLI runner for [Voiden](https://voiden.app) — execute `.void` files
outside the app, in terminals, and CI/CD pipelines.

`.void` files are created and edited inside the **Voiden desktop app**.
This package lets you run them anywhere Node.js is available: local terminals,
GitHub Actions, GitLab CI, Docker, and more.

---

## Table of contents

- [What is a .void file?](#what-is-a-void-file)
- [Installation](#installation)
- [Quick start](#quick-start)
- [Commands](#commands)
  - [run](#run)
  - [plugin install](#plugin-install)
  - [plugin uninstall](#plugin-uninstall)
  - [plugin enable / disable](#plugin-enable--disable)
  - [plugin list](#plugin-list)
- [Plugins](#plugins)
  - [How plugins work](#how-plugins-work)
  - [voiden-scripting](#voiden-scripting)
  - [simple-assertions](#simple-assertions)
  - [voiden-faker](#voiden-faker)
  - [voiden-advanced-auth](#voiden-advanced-auth)
  - [voiden-graphql](#voiden-graphql)
- [RunnerContext API](#runnercontext-api)
- [Writing a custom runner plugin](#writing-a-custom-runner-plugin)
- [Output formats](#output-formats)
- [Environment variables](#environment-variables)
- [Exit codes](#exit-codes)
- [CI/CD](#cicd)
- [Supported protocols](#supported-protocols)
- [Architecture](#architecture)

---

## What is a .void file?

A `.void` file is a request document created in the Voiden app. It encodes one
API request — REST, WebSocket, or gRPC — along with its headers, query params,
body, pre-request scripts, and assertions, all in a structured format.

```
requests/
  auth.void           ← POST /auth/login
  get-users.void      ← GET  /users
  create-post.void    ← POST /posts
  ws-events.void      ← WebSocket wss://...
  search.void         ← GraphQL query
```

---

## Installation

```bash
npm install -g @voiden/runner
```

Requires Node.js 18 or later.

---

## Quick start

```bash
# 1. Install bundled plugins (one-time setup)
voiden-runner plugin install --all

# 2. Run a single file
voiden-runner run auth.void

# 3. Run an entire folder (recursive)
voiden-runner run ./requests/

# 4. Run with environment variable substitution
voiden-runner run ./requests/ --env .env

# 5. CI mode — exit 1 if any request fails
voiden-runner run ./requests/ --env .env.ci --fail-on-error
```

---

## Commands

### `run`

```
voiden-runner run <paths...> [options]
```

Runs one or more `.void` files. `<paths...>` accepts any mix of:

| Input | Behaviour |
|---|---|
| `auth.void` | Run a single file |
| `./requests/` | Recursively run every `.void` file in a directory |
| `auth.void users.void` | Run multiple named files in order |
| `./smoke/ ./regression/` | Run multiple directories |
| `./requests/*.void` | Glob pattern |

**Options**

| Flag | Default | Description |
|---|---|---|
| `-e, --env <path>` | — | Path to a `.env` file. Keys become `{{VARIABLE}}` substitutions in the request. |
| `-f, --format <format>` | `table` | Output format: `table` (human-readable) or `json`. |
| `--show-body` | off | Print the response body (truncated to 800 chars / 20 lines) below each result. |
| `--fail-on-error` | off | Exit with code `1` if any request fails. Use in CI pipelines. |
| `--verbose` | off | Print plugin logs, script output, and section dividers. |

**Examples**

```bash
# Run all files in a folder with staging env
voiden-runner run ./requests/ --env .env.staging

# CI pipeline — JSON output piped to a file
voiden-runner run ./requests/ \
  --env .env.ci \
  --fail-on-error \
  --format json | tee results.json

# Debug a single request — print body and all plugin logs
voiden-runner run auth.void --show-body --verbose
```

---

### `plugin install`

```
voiden-runner plugin install [names...] [--all]
```

Installs one or more plugins from `@voiden/core-extensions`. State is persisted
to `~/.voiden/plugins.json`.

```bash
# Install every available plugin
voiden-runner plugin install --all

# Install specific plugins
voiden-runner plugin install simple-assertions voiden-faker
```

---

### `plugin uninstall`

```
voiden-runner plugin uninstall <name>
```

Removes a plugin from the local store.

```bash
voiden-runner plugin uninstall voiden-faker
```

---

### `plugin enable / disable`

```
voiden-runner plugin enable  <name>
voiden-runner plugin disable <name>
```

Toggle a plugin without uninstalling it. Useful for isolating failures — disable
one plugin at a time to narrow down which one is affecting a request.

```bash
voiden-runner plugin disable voiden-scripting
voiden-runner run failing.void
voiden-runner plugin enable voiden-scripting
```

---

### `plugin list`

```
voiden-runner plugin list
```

Lists all available plugins, their install status, and whether a headless runner
entry has been published for each one.

```
  Available plugins  (@voiden/core-extensions)
────────────────────────────────────────────────────────────────
  voiden-scripting          ✓ enabled
    Pre-request and post-response JavaScript script execution
  simple-assertions         ✓ enabled
    Assertion testing against HTTP responses
  voiden-faker              ✓ enabled
    Replace {{$faker.XXX()}} patterns with generated fake data
  voiden-advanced-auth      ✓ enabled
    Inject Bearer, Basic, and API Key auth into requests
  voiden-graphql            ✓ enabled
    Transform GraphQL query/variables blocks into HTTP POST requests
```

---

## Plugins

### How plugins work

The runner has a two-hook pipeline:

```
┌──────────────────────────────────────────────────────────────┐
│  .void file ──► parser ──► blocks[]                         │
│                                                              │
│  ① onBuildRequest(request, blocks)                          │
│     Each enabled plugin can read and modify the request      │
│     before it is sent. Handlers run in load order.           │
│                                                              │
│  HTTP / WS / gRPC ──► response                              │
│                                                              │
│  ② onProcessResponse(response, blocks, request)             │
│     Each plugin reads the response and emits structured      │
│     report entries (assertions, logs, sections).             │
│                                                              │
│  Report entries printed below the result line               │
└──────────────────────────────────────────────────────────────┘
```

Plugins are loaded from `@voiden/core-extensions` via their `runner` subpath
export (e.g. `@voiden/core-extensions/voiden-scripting/runner`). Each plugin
exports a single `RunnerFactory` function as its default export.

---

### `voiden-scripting`

Executes pre-request and post-response **JavaScript** scripts embedded as
`pre_script` / `post_script` blocks in the `.void` file.

- **Hooks:** `onBuildRequest` (pre-script) + `onProcessResponse` (post-script)
- **Supported languages in CLI:** JavaScript only.
  Python and Shell scripts require Electron IPC (desktop app only) and are
  skipped with a `[warn]` log entry.

**Script globals — `voiden` / `vd`**

| Property / Method | Type | Description |
|---|---|---|
| `voiden.request` | object | The outgoing request: `url`, `method`, `headers[]`, `queryParams[]`, `pathParams[]`, `body` |
| `voiden.response` | object \| null | The received response (post-script only): `status`, `statusText`, `body`, `time`, `size` |
| `voiden.env.get(key)` | `(key: string) => string \| undefined` | Read a value from the `--env` file |
| `voiden.assert(actual, operator, expected, message?)` | function | Emit a pass/fail assertion into the report |
| `voiden.log(level?, ...args)` | function | Emit a log line (shown with `--verbose`) |
| `voiden.cancel()` | function | No-op in CLI context |

**Mutating the request (pre-script):**

Assign directly to `voiden.request` properties. The runner reads the final
state after the script completes.

```javascript
// pre_script — add a timestamp header
voiden.request.headers.push({ key: 'X-Run-Ts', value: Date.now().toString() })
voiden.log('info', 'Added X-Run-Ts header')
```

**Asserting on the response (post-script):**

```javascript
// post_script
const body = typeof voiden.response.body === 'string'
  ? JSON.parse(voiden.response.body)
  : voiden.response.body

voiden.assert(voiden.response.status, '==',     200,    'status is 200')
voiden.assert(body.id,                'truthy', null,   'response has id')
voiden.assert(body.items.length,      '>',      0,      'items array is non-empty')
```

**Supported assertion operators:**

`==` `===` `!=` `!==` `>` `>=` `<` `<=`
`contains` `includes` `matches` (regex) `truthy` `falsy`
`eq` `neq` `gte` `lte` `greater` `less`

---

### `simple-assertions`

Evaluates assertion rows from an `assertions-table` block against the HTTP
response and emits structured pass/fail report entries.

- **Hook:** `onProcessResponse`

**Assertion columns**

| Column | Description |
|---|---|
| `description` | Human-readable label shown in the output |
| `field` | Path into the response to extract the actual value |
| `operator` | Comparison operator (see list below) |
| `expectedValue` | Value to compare against (supports `{{ENV_VAR}}`) |

**Field path syntax**

| Path | Resolves to |
|---|---|
| `status` / `statusCode` | HTTP status code (number) |
| `statusText` | HTTP status text (string) |
| `responseTime` / `duration` | Response time in milliseconds |
| `header.<Name>` | Value of a response header |
| `body.data.id` | JSON path into the parsed response body |
| `body.items[0].name` | Array index access |

**Operators**

| Operator | Description |
|---|---|
| `equals` / `eq` | Strict equality |
| `notEquals` / `neq` | Strict inequality |
| `contains` | String/array contains |
| `notContains` | String/array does not contain |
| `startsWith` | String starts with |
| `endsWith` | String ends with |
| `greaterThan` / `gt` | Numeric greater-than |
| `lessThan` / `lt` | Numeric less-than |
| `greaterThanOrEqual` / `gte` | Numeric ≥ |
| `lessThanOrEqual` / `lte` | Numeric ≤ |
| `isEmpty` | Empty string, array, or null/undefined |
| `isNotEmpty` | Not empty |
| `isNull` | Null or undefined |
| `isNotNull` | Not null/undefined |
| `matches` | Regex match |
| `exists` | Property exists in the response |
| `notExists` | Property does not exist |

---

### `voiden-faker`

Replaces `{{$faker.category.method(args)}}` patterns in the URL, headers,
query params, and body **before the request is sent**.

- **Hook:** `onBuildRequest`
- **Powered by:** [`@faker-js/faker`](https://fakerjs.dev/)

**Syntax:** `{{$faker.<category>.<method>(<args>)}}`

**Common patterns**

| Pattern | Example output |
|---|---|
| `{{$faker.person.firstName()}}` | `Lena` |
| `{{$faker.person.lastName()}}` | `Müller` |
| `{{$faker.internet.email()}}` | `user.42@example.com` |
| `{{$faker.internet.url()}}` | `https://spiffy-board.net` |
| `{{$faker.string.uuid()}}` | `3b12f1df-5232-4804-a3ee-f3a856ca33b2` |
| `{{$faker.number.int({"min":1,"max":100})}}` | `42` |
| `{{$faker.date.recent()}}` | `2025-03-14T10:22:00.000Z` |
| `{{$faker.lorem.sentence()}}` | `Foo bar baz qux.` |

JSON bodies are parsed, faker patterns replaced inside string values, then
re-serialised — so structured bodies stay valid JSON.

---

### `voiden-advanced-auth`

Reads the `auth-node` block from the `.void` file and injects authentication
into the request before it is sent.

- **Hook:** `onBuildRequest`

**Auth types supported in CLI**

| Type | Injected as |
|---|---|
| `bearer` | `Authorization: Bearer <token>` |
| `basic` | `Authorization: Basic <base64(username:password)>` |
| `apiKey` (header) | `<key>: <value>` header |
| `apiKey` (query) | `?<key>=<value>` appended to the URL |

**Auth types requiring the desktop app (skipped in CLI)**

OAuth 2.0 (auto-refresh), OAuth 1.0, AWS Signature V4, Digest, NTLM, Hawk.
These emit a `[warn]` log entry and the request is sent without auth.

`{{ENV_VAR}}` patterns in token / username / password / key / value fields
are resolved from the `--env` file before injection.

---

### `voiden-graphql`

Detects `gqlquery` and `gqlvariables` blocks and rewrites the request as a
standard GraphQL-over-HTTP POST before it is sent.

- **Hook:** `onBuildRequest`

**Transform applied**

- Method set to `POST`
- `Content-Type: application/json` header added (replaces any existing one)
- Body set to `{ "query": "...", "variables": { ... } }`

If there is no `gqlquery` block the plugin is a no-op and the request is sent
as-is.

**Example `.void` file**

```
url https://api.example.com/graphql

gqlquery
  query GetUser($id: ID!) {
    user(id: $id) {
      name
      email
    }
  }

gqlvariables
  { "id": "{{USER_ID}}" }
```

---

## RunnerContext API

Every plugin factory receives a `RunnerContext`. The types are exported from
`@voiden/sdk/runner`:

```typescript
import type { RunnerFactory, RunnerContext } from '@voiden/sdk/runner'
```

---

### `context.onBuildRequest(handler)`

Register a pre-request handler. Called after parsing, before the request is sent.

```typescript
context.onBuildRequest(async (request, blocks) => {
  // request : CliRequestState
  //   .method      string
  //   .url         string
  //   .headers     Array<{ key, value, enabled? }>
  //   .queryParams Array<{ key, value, enabled? }>
  //   .pathParams  Array<{ key, value, enabled? }> | undefined
  //   .body        string | undefined
  //   .contentType string | undefined
  //   .metadata    Record<string, any> | undefined
  //
  // blocks : Block[]  — parsed .void document nodes

  // Return a modified request to override, or return nothing / undefined
  // to leave the request unchanged.
  return {
    ...request,
    headers: [...request.headers, { key: 'X-Trace-Id', value: crypto.randomUUID(), enabled: true }],
  }
})
```

Multiple plugins can register `onBuildRequest` handlers. They execute in
plugin load order, each receiving the output of the previous handler.

---

### `context.onProcessResponse(handler)`

Register a post-response handler. Called after the response is received.

```typescript
context.onProcessResponse(async (response, blocks, request) => {
  // response : CliResponseState
  //   .protocol    string
  //   .method      string | undefined
  //   .url         string
  //   .status      number | undefined
  //   .statusText  string | undefined
  //   .durationMs  number
  //   .size        number | undefined
  //   .body        string | undefined
  //   .error       string | undefined
  //   .connected   boolean | undefined
  //   .metadata    Record<string, any> | undefined
  //
  // blocks  : Block[]         — same nodes as above
  // request : CliRequestState — the final request that was sent

  context.report.add({
    type:     'assertion',
    passed:   response.status === 200,
    message:  'status is 200',
    actual:   response.status,
    expected: 200,
    operator: '==',
  })
})
```

---

### `context.report`

Structured output API. Entries are collected and printed below the request
result line. Three entry types are supported:

#### `log`

```typescript
context.report.add({
  type:    'log',
  level:   'info',   // 'info' | 'warn' | 'error' | 'debug'
  message: 'Token refreshed successfully',
})
```

- `error` logs are always printed.
- `info`, `warn`, `debug` logs are only printed when `--verbose` is set.

#### `assertion`

```typescript
context.report.add({
  type:     'assertion',
  passed:   true,
  message:  'response time < 500ms',
  actual:   response.durationMs,   // shown on failure
  expected: 500,                   // shown on failure
  operator: '<',                   // shown on failure
})
```

Assertions are always printed. Failed assertions show `actual` vs `expected`.

#### `section`

```typescript
context.report.add({
  type:  'section',
  title: 'Auth checks',
})
```

Section headers group related entries visually. Only shown with `--verbose`.

---

### `context.env`

Flat map of all variables loaded from the `--env` file.

```typescript
const apiKey = context.env['API_KEY']
if (!apiKey) {
  context.report.add({ type: 'log', level: 'warn', message: 'API_KEY not set in env file' })
  return
}
```

---

### `context.verbose`

`true` when the user passed `--verbose`. Gate debug-only output behind this flag.

```typescript
if (context.verbose) {
  context.report.add({ type: 'log', level: 'debug', message: `resolved token: ${token.slice(0, 8)}…` })
}
```

---

## Writing a custom runner plugin

A runner plugin is a module that exports a `RunnerFactory` as its default export.

```typescript
// my-plugin/runner.ts
import type { RunnerFactory } from '@voiden/sdk/runner'

const factory: RunnerFactory = (context) => ({
  async onload() {

    // ── Pre-request ──────────────────────────────────────────────
    context.onBuildRequest(async (request, blocks) => {
      // Find a custom block type defined by this plugin
      const cfg = blocks.find(b => b.type === 'my-auth-config')
      if (!cfg) return  // not a request this plugin handles

      const token = context.env[cfg.attrs?.tokenVar ?? '']
      if (!token) {
        context.report.add({ type: 'log', level: 'warn', message: 'my-plugin: token env var not set' })
        return
      }

      return {
        ...request,
        headers: [...request.headers, { key: 'Authorization', value: `Token ${token}`, enabled: true }],
      }
    })

    // ── Post-response ────────────────────────────────────────────
    context.onProcessResponse(async (response, _blocks) => {
      context.report.add({ type: 'section', title: 'My Plugin Checks' })

      context.report.add({
        type:     'assertion',
        passed:   (response.durationMs ?? 0) < 1000,
        message:  'response time < 1s',
        actual:   response.durationMs,
        expected: 1000,
        operator: '<',
      })

      if (context.verbose) {
        context.report.add({
          type:    'log',
          level:   'debug',
          message: `response size: ${response.size ?? 0} bytes`,
        })
      }
    })

  }
})

export default factory
```

**`package.json` — add the `runner` subpath export:**

```json
{
  "exports": {
    ".":        { "import": "./dist/index.js" },
    "./runner": {
      "types":   "./dist/runner.d.ts",
      "import":  "./dist/runner.js",
      "default": "./dist/runner.js"
    }
  }
}
```

**Register it in the runner's plugin registry** (`src/plugins/registry.ts`):

```typescript
{
  name:             'my-plugin',
  description:      'What my plugin does',
  runnerPath:       'my-plugin/runner',
  runnerAvailable:  true,
}
```

Then install it:

```bash
voiden-runner plugin install my-plugin
```

---

## Output formats

### `--format table` (default)

Human-readable coloured terminal output.

```
  voiden-runner · 3 files · 5 plugins active
────────────────────────────────────────────────────────────────

[1/3] auth.void
  ✓  REST POST   https://api.example.com/auth  200 OK  342ms  1.2KB

[2/3] users.void
  ✓  REST GET    https://api.example.com/users  200 OK  128ms  4.8KB
       assertions: 3 passed
       ✓  status is 200
       ✓  body has items array
       ✓  items count > 0

[3/3] delete-missing.void
  ✓  REST DELETE  https://api.example.com/users/999  404 Not Found  89ms
       assertions: 1 passed · 1 failed
       ✓  request completed
       ✗  status is 200  (got 404, expected == 200)

────────────────────────────────────────────────────────────────
  Summary  3 requests  ·  2 passed  ·  1 failed  ·  559ms total
────────────────────────────────────────────────────────────────
```

### `--format json`

Machine-readable JSON for CI integration and downstream tooling.

```json
{
  "summary": {
    "total": 3,
    "passed": 2,
    "failed": 1,
    "totalDurationMs": 559,
    "activePlugins": [
      "voiden-scripting",
      "simple-assertions",
      "voiden-faker",
      "voiden-advanced-auth",
      "voiden-graphql"
    ]
  },
  "requests": [
    {
      "file": "/path/to/auth.void",
      "protocol": "rest",
      "method": "POST",
      "url": "https://api.example.com/auth",
      "success": true,
      "status": 200,
      "statusText": "OK",
      "durationMs": 342,
      "size": 1229,
      "reportEntries": []
    },
    {
      "file": "/path/to/users.void",
      "protocol": "rest",
      "method": "GET",
      "url": "https://api.example.com/users",
      "success": true,
      "status": 200,
      "statusText": "OK",
      "durationMs": 128,
      "size": 4915,
      "reportEntries": [
        { "type": "section",   "title": "Assertions" },
        { "type": "assertion", "passed": true, "message": "status is 200" },
        { "type": "assertion", "passed": true, "message": "body has items array" },
        { "type": "assertion", "passed": true, "message": "items count > 0", "actual": 12, "expected": "0", "operator": ">" }
      ]
    }
  ]
}
```

---

## Environment variables

Use `{{VARIABLE_NAME}}` placeholders anywhere in a `.void` file — in the URL,
headers, query params, path params, request body, and assertion expected values.

**File format**

```env
# .env.staging
BASE_URL=https://staging.api.example.com
API_KEY=sk-staging-abc123
TOKEN="eyJhbGciOiJIUzI1NiJ9..."
USER_ID=42
```

Pass the file with `--env`:

```bash
voiden-runner run ./requests/ --env .env.staging
```

Variables are also available inside scripts via `voiden.env.get('KEY')` and
inside assertion expected values as `{{KEY}}`.

---

## Exit codes

| Code | Condition |
|---|---|
| `0` | All requests ran (regardless of HTTP status) unless `--fail-on-error` |
| `1` | One or more requests failed **and** `--fail-on-error` is set |
| `1` | Usage error — unrecognised flag, file not found, no `.void` files matched |

---

## CI/CD

### GitHub Actions

```yaml
jobs:
  void-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install runner
        run: npm install -g @voiden/runner

      - name: Install plugins
        run: voiden-runner plugin install --all

      - name: Write env file
        run: |
          echo "BASE_URL=${{ secrets.BASE_URL }}" >> .env.ci
          echo "API_KEY=${{ secrets.API_KEY }}"   >> .env.ci

      - name: Run .void tests
        run: |
          voiden-runner run ./tests/ \
            --env .env.ci \
            --fail-on-error \
            --format json | tee void-results.json

      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: void-test-results
          path: void-results.json
```

### GitLab CI

```yaml
void-tests:
  image: node:20
  script:
    - npm install -g @voiden/runner
    - voiden-runner plugin install --all
    - echo "BASE_URL=$BASE_URL" >> .env.ci
    - echo "API_KEY=$API_KEY"   >> .env.ci
    - voiden-runner run ./tests/ --env .env.ci --fail-on-error --format json | tee void-results.json
  artifacts:
    paths:
      - void-results.json
    when: always
```

### Docker / shell

```bash
npm install -g @voiden/runner
voiden-runner plugin install --all
voiden-runner run ./requests/ --env .env --fail-on-error
```

---

## Supported protocols

| Protocol | Description |
|---|---|
| REST | HTTP/HTTPS — GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS, … |
| WebSocket | `ws://` and `wss://` connections |
| gRPC | Unary and streaming calls via `.proto` definitions |

---

## Architecture

```
voiden-runner/src/
├── index.ts              CLI entry point — commands, output formatters
├── runner.ts             runVoidFile() — parse → build → plugins → execute
├── parser.ts             .void file text → Block[]
├── builder.ts            Block[] → RunRequest (REST / WS / gRPC)
├── types.ts              RunResult, RunRequest, CliReportEntry
├── pluginContext.ts       createRunnerContext(), RunnerContext
│
├── protocols/
│   ├── rest.ts           executeRest()      — fetch-based HTTP client
│   ├── websocket.ts      executeWebSocket() — ws library client
│   └── grpc.ts           executeGrpc()      — @grpc/grpc-js client
│
└── plugins/
    ├── registry.ts       CORE_PLUGINS — name → runnerPath map
    ├── store.ts          ~/.voiden/plugins.json — install/enable state
    └── loader.ts         loadEnabledPlugins() — dynamic import of runner entries
```

### Request lifecycle

```
runVoidFile(filePath, options)
  │
  ├─ parseVoidFile(content)          → Block[]
  ├─ buildRequest(blocks)            → RunRequest
  ├─ createRunnerContext(env)        → { context, requestHandlers, responseHandlers, report }
  ├─ loadEnabledPlugins(context)     → plugins call onBuildRequest / onProcessResponse to register handlers
  │
  ├─ for each requestHandler (in order):
  │    modified = await handler(request, blocks)
  │    if modified → request = modified
  │
  ├─ executeRest(request)            → RunResult
  │  executeWebSocket(request)
  │  executeGrpc(request)
  │
  ├─ for each responseHandler (in order):
  │    await handler(response, blocks, request)
  │    plugins call context.report.add(...)
  │
  └─ return {
       result: { ...RunResult, reportEntries: report.getEntries() },
       activePlugins
     }
```

### Plugin state file

`~/.voiden/plugins.json` — created on first `plugin install`.

```json
{
  "installedPlugins": {
    "voiden-scripting":     { "installedAt": "2025-01-01T00:00:00Z", "enabled": true },
    "simple-assertions":    { "installedAt": "2025-01-01T00:00:00Z", "enabled": true },
    "voiden-faker":         { "installedAt": "2025-01-01T00:00:00Z", "enabled": true },
    "voiden-advanced-auth": { "installedAt": "2025-01-01T00:00:00Z", "enabled": true },
    "voiden-graphql":       { "installedAt": "2025-01-01T00:00:00Z", "enabled": true }
  }
}
```

---

## Related

- **Voiden app** — create and edit `.void` files visually at [voiden.app](https://voiden.app)
- **@voiden/sdk** — SDK for building Voiden plugins (includes `RunnerFactory`, `ThemeClasses`, etc.)
- **@voiden/core-extensions** — bundled plugins: scripting, assertions, faker, auth, GraphQL
